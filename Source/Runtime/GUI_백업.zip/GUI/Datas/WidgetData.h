#pragma once
#include "Core.h"

//JGCLASS()
//class PWidgetData : public JGObject
//{
//	JG_GENERATED_CLASS_BODY
//public:
//	JGPROPERTY()
//	HGuid Guid;
//
//	JGPROPERTY()
//	bool IsOpen;
//
//	PWidgetData() : IsOpen(false) {}
//	virtual ~PWidgetData() = default;
//};
//
