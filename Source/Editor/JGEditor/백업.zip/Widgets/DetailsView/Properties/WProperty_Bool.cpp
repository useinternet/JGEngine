#include "PCH/PCH.h"
#include "WProperty_Bool.h"

void WProperty_Bool::Construct(const HArguments& inArgs)
{
	_property = inArgs.Property;
}
