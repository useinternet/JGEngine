#pragma once
#include "WidgetComponents/WidgetComponent.h"
#include "JGEditorDefine.h"



class JGEDITOR_API WDetailsView : public WWidgetComponent
{
public:
	struct HArguments
	{
		HList<PWeakPtr<JGObject>> DetailsObjects;
	};

private:
	HList<PWeakPtr<JGObject>> _detailsObjects;

public:
	WDetailsView() = default;
	virtual ~WDetailsView() = default;

	void Construct(const HArguments& inArgs);

protected:
	virtual void OnGUIBuild(HGUIBuilder& inBuilder) override;
};